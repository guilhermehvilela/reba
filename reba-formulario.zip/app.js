// REBA Tables and Risk Levels
const REBA_TABLES = {
    table_a: [
        [[1,2,3,4], [1,2,3,4], [3,3,5,6]],
        [[2,3,4,5], [3,4,5,6], [4,5,6,7]],
        [[2,4,5,6], [4,5,6,7], [5,6,7,8]],
        [[3,5,6,7], [5,6,7,8], [6,7,8,9]],
        [[4,6,7,8], [6,7,8,9], [7,8,9,9]]
    ],
    table_b: [
        [[1,2,2], [1,2,3]],
        [[1,2,3], [2,3,4]],
        [[3,4,5], [4,5,5]],
        [[4,5,5], [5,6,7]],
        [[6,7,8], [7,8,8]],
        [[7,8,8], [8,9,9]]
    ],
    table_c: [
        [1,1,1,2,3,3,4,5,6,7,7,7],
        [1,2,2,3,4,4,5,6,6,7,7,8],
        [2,3,3,3,4,5,6,7,7,8,8,8],
        [3,4,4,4,5,6,7,8,8,9,9,9],
        [4,4,4,5,6,7,8,8,9,9,9,9],
        [6,6,6,7,8,8,9,9,10,10,10,10],
        [7,7,7,8,9,9,9,10,10,11,11,11],
        [8,8,8,9,10,10,10,10,10,11,11,11],
        [9,9,9,10,10,10,11,11,11,12,12,12],
        [10,10,10,11,11,11,11,12,12,12,12,12],
        [11,11,11,11,12,12,12,12,12,12,12,12],
        [12,12,12,12,12,12,12,12,12,12,12,12]
    ]
};

const RISK_LEVELS = [
    {score: 1, risk: "negligível", action: "Nenhuma ação necessária", color: "#4CAF50"},
    {score_range: [2,3], risk: "baixo", action: "Mudança pode ser necessária", color: "#8BC34A"},
    {score_range: [4,7], risk: "médio", action: "Investigar, mudança em breve", color: "#FFC107"},
    {score_range: [8,10], risk: "alto", action: "Investigar e implementar mudança", color: "#FF9800"},
    {score_range: [11,15], risk: "muito alto", action: "Implementar mudança imediatamente", color: "#F44336"}
];

class REBACalculator {
    constructor() {
        this.form = document.getElementById('rebaForm');
        this.initializeForm();
        this.attachEventListeners();
        this.setDefaultDate();
        
        // Initial calculation
        setTimeout(() => this.calculateScores(), 100);
    }

    initializeForm() {
        // Initialize score displays
        this.scoreElements = {
            scoreA: document.getElementById('scoreA'),
            scoreB: document.getElementById('scoreB'),
            scoreAFinal: document.getElementById('scoreAFinal'),
            scoreBFinal: document.getElementById('scoreBFinal'),
            scoreC: document.getElementById('scoreC'),
            scoreFinal: document.getElementById('scoreFinal'),
            riskInterpretation: document.getElementById('riskInterpretation')
        };

        this.exportButtons = {
            excel: document.getElementById('exportExcel'),
            pdf: document.getElementById('exportPDF')
        };
    }

    setDefaultDate() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('data').value = today;
    }

    attachEventListeners() {
        // Add change listeners to all form inputs
        const inputs = this.form.querySelectorAll('input[type="radio"], input[type="checkbox"]');
        inputs.forEach(input => {
            input.addEventListener('change', () => {
                console.log(`Input changed: ${input.name} = ${input.value || input.checked}`);
                this.calculateScores();
            });
        });

        // Export button listeners
        this.exportButtons.excel.addEventListener('click', () => this.exportToExcel());
        this.exportButtons.pdf.addEventListener('click', () => this.exportToPDF());

        // Form validation on required fields
        const requiredInputs = this.form.querySelectorAll('input[required]');
        requiredInputs.forEach(input => {
            input.addEventListener('blur', () => this.validateField(input));
        });
    }

    validateField(field) {
        const formGroup = field.closest('.form-group');
        if (field.value.trim() === '') {
            formGroup?.classList.add('error');
        } else {
            formGroup?.classList.remove('error');
        }
    }

    getSelectedValue(name) {
        const element = this.form.querySelector(`input[name="${name}"]:checked`);
        const value = element ? parseInt(element.value) : null;
        console.log(`Getting ${name}: ${value}`);
        return value;
    }

    getCheckboxAdjustments(baseName) {
        let adjustment = 0;
        const checkboxes = this.form.querySelectorAll(`input[name^="${baseName}_"]:checked`);
        
        checkboxes.forEach(checkbox => {
            const name = checkbox.name;
            console.log(`Checkbox ${name} is checked`);
            if (name.includes('apoiado')) {
                adjustment -= 1; // Braço apoiado é -1
            } else {
                adjustment += 1; // Outros ajustes são +1
            }
        });
        
        console.log(`${baseName} adjustments: ${adjustment}`);
        return adjustment;
    }

    calculateGroupA() {
        const pescoco = this.getSelectedValue('pescoco');
        const tronco = this.getSelectedValue('tronco');
        const pernas = this.getSelectedValue('pernas');

        console.log(`Group A: pescoco=${pescoco}, tronco=${tronco}, pernas=${pernas}`);

        if (pescoco === null || tronco === null || pernas === null) {
            console.log('Group A incomplete');
            return null;
        }

        // Get base score from Table A
        const baseScore = REBA_TABLES.table_a[tronco - 1][pescoco - 1][pernas - 1];
        console.log(`Table A base score: ${baseScore}`);
        
        // Add adjustments
        const pescocoAdjust = this.getCheckboxAdjustments('pescoco');
        const troncoAdjust = this.getCheckboxAdjustments('tronco');
        
        const adjustedScore = baseScore + pescocoAdjust + troncoAdjust;
        const finalScore = Math.max(1, adjustedScore);
        
        console.log(`Group A final score: ${finalScore}`);
        return finalScore;
    }

    calculateGroupB() {
        const braco = this.getSelectedValue('braco');
        const antebraco = this.getSelectedValue('antebraco');
        const punho = this.getSelectedValue('punho');

        console.log(`Group B: braco=${braco}, antebraco=${antebraco}, punho=${punho}`);

        if (braco === null || antebraco === null || punho === null) {
            console.log('Group B incomplete');
            return null;
        }

        // Get base score from Table B
        const baseScore = REBA_TABLES.table_b[braco - 1][antebraco - 1][punho - 1];
        console.log(`Table B base score: ${baseScore}`);
        
        // Add adjustments
        const bracoAdjust = this.getCheckboxAdjustments('braco');
        const punhoAdjust = this.getCheckboxAdjustments('punho');
        
        const adjustedScore = baseScore + bracoAdjust + punhoAdjust;
        const finalScore = Math.max(1, adjustedScore);
        
        console.log(`Group B final score: ${finalScore}`);
        return finalScore;
    }

    calculateFinalScores() {
        const scoreA = this.calculateGroupA();
        const scoreB = this.calculateGroupB();

        console.log(`Initial scores: A=${scoreA}, B=${scoreB}`);

        if (scoreA === null || scoreB === null) {
            return { scoreA: null, scoreB: null, scoreAFinal: null, scoreBFinal: null, scoreC: null, scoreFinal: null };
        }

        // Calculate Score A Final (Score A + Force)
        const forca = this.getSelectedValue('forca') || 0;
        const forcaAdjust = this.getCheckboxAdjustments('forca');
        const scoreAFinal = scoreA + forca + forcaAdjust;

        // Calculate Score B Final (Score B + Coupling)
        const pega = this.getSelectedValue('pega') || 0;
        const scoreBFinal = scoreB + pega;

        // Calculate Score C from Table C
        const scoreC = REBA_TABLES.table_c[Math.min(scoreAFinal - 1, 11)][Math.min(scoreBFinal - 1, 11)];

        // Calculate Final REBA Score (Score C + Activity)
        const atividadeAdjust = this.getCheckboxAdjustments('atividade');
        const scoreFinal = scoreC + atividadeAdjust;

        console.log(`Final scores: A=${scoreA}, B=${scoreB}, AFinal=${scoreAFinal}, BFinal=${scoreBFinal}, C=${scoreC}, Final=${scoreFinal}`);

        return {
            scoreA,
            scoreB,
            scoreAFinal,
            scoreBFinal,
            scoreC,
            scoreFinal
        };
    }

    calculateScores() {
        console.log('Calculating scores...');
        const scores = this.calculateFinalScores();
        
        // Update display
        this.scoreElements.scoreA.textContent = scores.scoreA !== null ? scores.scoreA : '-';
        this.scoreElements.scoreB.textContent = scores.scoreB !== null ? scores.scoreB : '-';
        this.scoreElements.scoreAFinal.textContent = scores.scoreAFinal !== null ? scores.scoreAFinal : '-';
        this.scoreElements.scoreBFinal.textContent = scores.scoreBFinal !== null ? scores.scoreBFinal : '-';
        this.scoreElements.scoreC.textContent = scores.scoreC !== null ? scores.scoreC : '-';
        this.scoreElements.scoreFinal.textContent = scores.scoreFinal !== null ? scores.scoreFinal : '-';

        // Update risk interpretation
        this.updateRiskInterpretation(scores.scoreFinal);

        // Enable/disable export buttons
        const isComplete = scores.scoreFinal !== null && this.isFormValid();
        this.exportButtons.excel.disabled = !isComplete;
        this.exportButtons.pdf.disabled = !isComplete;
    }

    isFormValid() {
        const requiredFields = ['funcao', 'gse', 'avaliador', 'data'];
        return requiredFields.every(field => {
            const element = document.getElementById(field);
            return element && element.value.trim() !== '';
        });
    }

    updateRiskInterpretation(score) {
        if (score === null) {
            this.scoreElements.riskInterpretation.innerHTML = '<p>Preencha todos os campos para ver a interpretação do risco.</p>';
            this.scoreElements.riskInterpretation.className = 'risk-interpretation';
            return;
        }

        let riskLevel = null;
        for (const level of RISK_LEVELS) {
            if (level.score && level.score === score) {
                riskLevel = level;
                break;
            } else if (level.score_range && score >= level.score_range[0] && score <= level.score_range[1]) {
                riskLevel = level;
                break;
            }
        }

        if (riskLevel) {
            const className = riskLevel.score ? 'risk-1' : `risk-${riskLevel.score_range[0]}-${riskLevel.score_range[1]}`;
            this.scoreElements.riskInterpretation.className = `risk-interpretation ${className}`;
            this.scoreElements.riskInterpretation.innerHTML = `
                <h3>Risco ${riskLevel.risk.toUpperCase()}</h3>
                <p><strong>Ação Recomendada:</strong> ${riskLevel.action}</p>
                <p><strong>Score REBA:</strong> ${score}</p>
            `;
        }
    }

    getFormData() {
        const data = {};
        
        // Get text inputs
        const textInputs = this.form.querySelectorAll('input[type="text"], input[type="date"], textarea');
        textInputs.forEach(input => {
            data[input.name] = input.value;
        });

        // Get radio buttons
        const radioInputs = this.form.querySelectorAll('input[type="radio"]:checked');
        radioInputs.forEach(input => {
            data[input.name] = input.value;
        });

        // Get checkboxes
        const checkboxInputs = this.form.querySelectorAll('input[type="checkbox"]');
        checkboxInputs.forEach(input => {
            data[input.name] = input.checked;
        });

        // Get calculated scores
        const scores = this.calculateFinalScores();
        return { ...data, scores };
    }

    exportToExcel() {
        if (!window.XLSX) {
            alert('Biblioteca de exportação Excel não encontrada. Verifique a conexão com a internet.');
            return;
        }

        const data = this.getFormData();
        const scores = data.scores;
        
        const workbook = XLSX.utils.book_new();
        
        // Create worksheet data
        const wsData = [
            ['FORMULÁRIO REBA - AVALIAÇÃO RÁPIDA DE CORPO INTEIRO'],
            [''],
            ['DADOS GERAIS'],
            ['Função', data.funcao || ''],
            ['GSE', data.gse || ''],
            ['Avaliador', data.avaliador || ''],
            ['Data', data.data || ''],
            ['Descrição da Tarefa', data.descricao || ''],
            [''],
            ['AVALIAÇÃO - GRUPO A'],
            ['Pescoço', data.pescoco || ''],
            ['Ajustes Pescoço', `Torção: ${data.pescoco_torcao ? 'Sim' : 'Não'}, Lateral: ${data.pescoco_lateral ? 'Sim' : 'Não'}`],
            ['Tronco', data.tronco || ''],
            ['Ajustes Tronco', `Torção: ${data.tronco_torcao ? 'Sim' : 'Não'}, Lateral: ${data.tronco_lateral ? 'Sim' : 'Não'}`],
            ['Pernas', data.pernas || ''],
            ['Score A', scores.scoreA || ''],
            [''],
            ['AVALIAÇÃO - GRUPO B'],
            ['Braço Superior', data.braco || ''],
            ['Ajustes Braço', `Ombro: ${data.braco_ombro ? 'Sim' : 'Não'}, Abduzido: ${data.braco_abduzido ? 'Sim' : 'Não'}, Apoiado: ${data.braco_apoiado ? 'Sim' : 'Não'}`],
            ['Antebraço', data.antebraco || ''],
            ['Punho', data.punho || ''],
            ['Ajustes Punho', `Torção: ${data.punho_torcao ? 'Sim' : 'Não'}`],
            ['Score B', scores.scoreB || ''],
            [''],
            ['FATORES ADICIONAIS'],
            ['Força/Carga', data.forca || ''],
            ['Força Brusca', data.forca_brusca ? 'Sim' : 'Não'],
            ['Pega/Acoplamento', data.pega || ''],
            ['Atividades', `Estática: ${data.atividade_estatica ? 'Sim' : 'Não'}, Repetitiva: ${data.atividade_repetitiva ? 'Sim' : 'Não'}, Instável: ${data.atividade_instavel ? 'Sim' : 'Não'}`],
            [''],
            ['RESULTADOS FINAIS'],
            ['Score A Final', scores.scoreAFinal || ''],
            ['Score B Final', scores.scoreBFinal || ''],
            ['Score C', scores.scoreC || ''],
            ['SCORE REBA FINAL', scores.scoreFinal || ''],
            [''],
            ['INTERPRETAÇÃO DO RISCO'],
        ];

        // Add risk interpretation
        if (scores.scoreFinal) {
            const riskLevel = this.getRiskLevel(scores.scoreFinal);
            if (riskLevel) {
                wsData.push(['Nível de Risco', riskLevel.risk.toUpperCase()]);
                wsData.push(['Ação Recomendada', riskLevel.action]);
            }
        }

        const worksheet = XLSX.utils.aoa_to_sheet(wsData);
        XLSX.utils.book_append_sheet(workbook, worksheet, 'REBA Assessment');
        
        const fileName = `REBA_${data.funcao || 'Assessment'}_${data.data || new Date().toISOString().split('T')[0]}.xlsx`;
        XLSX.writeFile(workbook, fileName);
    }

    exportToPDF() {
        if (!window.jsPDF) {
            alert('Biblioteca de exportação PDF não encontrada. Verifique a conexão com a internet.');
            return;
        }

        const data = this.getFormData();
        const scores = data.scores;
        
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        let yPosition = 20;
        const lineHeight = 7;
        const pageHeight = doc.internal.pageSize.height;
        
        function addText(text, x = 20, fontSize = 12, style = 'normal') {
            if (yPosition > pageHeight - 20) {
                doc.addPage();
                yPosition = 20;
            }
            doc.setFontSize(fontSize);
            doc.setFont('helvetica', style);
            doc.text(text, x, yPosition);
            yPosition += lineHeight;
        }
        
        function addSection(title) {
            yPosition += 5;
            addText(title, 20, 14, 'bold');
            yPosition += 3;
        }
        
        // Header
        addText('FORMULÁRIO REBA', 20, 18, 'bold');
        addText('Avaliação Rápida de Corpo Inteiro', 20, 12, 'normal');
        yPosition += 10;
        
        // Dados Gerais
        addSection('DADOS GERAIS');
        addText(`Função: ${data.funcao || 'N/A'}`);
        addText(`GSE: ${data.gse || 'N/A'}`);
        addText(`Avaliador: ${data.avaliador || 'N/A'}`);
        addText(`Data: ${data.data || 'N/A'}`);
        if (data.descricao) {
            addText(`Descrição: ${data.descricao}`);
        }
        
        // Grupo A
        addSection('GRUPO A - TRONCO, PESCOÇO E PERNAS');
        addText(`Pescoço: ${data.pescoco || 'N/A'} ${data.pescoco_torcao ? '(+1 Torção)' : ''} ${data.pescoco_lateral ? '(+1 Lateral)' : ''}`);
        addText(`Tronco: ${data.tronco || 'N/A'} ${data.tronco_torcao ? '(+1 Torção)' : ''} ${data.tronco_lateral ? '(+1 Lateral)' : ''}`);
        addText(`Pernas: ${data.pernas || 'N/A'}`);
        addText(`Score A: ${scores.scoreA || 'N/A'}`, 20, 12, 'bold');
        
        // Grupo B
        addSection('GRUPO B - BRAÇO, ANTEBRAÇO E PUNHO');
        addText(`Braço: ${data.braco || 'N/A'} ${data.braco_ombro ? '(+1 Ombro)' : ''} ${data.braco_abduzido ? '(+1 Abduzido)' : ''} ${data.braco_apoiado ? '(-1 Apoiado)' : ''}`);
        addText(`Antebraço: ${data.antebraco || 'N/A'}`);
        addText(`Punho: ${data.punho || 'N/A'} ${data.punho_torcao ? '(+1 Torção)' : ''}`);
        addText(`Score B: ${scores.scoreB || 'N/A'}`, 20, 12, 'bold');
        
        // Fatores Adicionais
        addSection('FATORES ADICIONAIS');
        addText(`Força/Carga: ${data.forca || 'N/A'} ${data.forca_brusca ? '(+1 Brusca)' : ''}`);
        addText(`Pega: ${data.pega || 'N/A'}`);
        const atividades = [];
        if (data.atividade_estatica) atividades.push('Estática');
        if (data.atividade_repetitiva) atividades.push('Repetitiva');
        if (data.atividade_instavel) atividades.push('Instável');
        addText(`Atividades: ${atividades.length ? atividades.join(', ') : 'Nenhuma'}`);
        
        // Resultados
        addSection('RESULTADOS FINAIS');
        addText(`Score A Final: ${scores.scoreAFinal || 'N/A'}`);
        addText(`Score B Final: ${scores.scoreBFinal || 'N/A'}`);
        addText(`Score C: ${scores.scoreC || 'N/A'}`);
        yPosition += 5;
        addText(`SCORE REBA FINAL: ${scores.scoreFinal || 'N/A'}`, 20, 16, 'bold');
        
        // Risk Interpretation
        if (scores.scoreFinal) {
            const riskLevel = this.getRiskLevel(scores.scoreFinal);
            if (riskLevel) {
                addSection('INTERPRETAÇÃO DO RISCO');
                addText(`Nível de Risco: ${riskLevel.risk.toUpperCase()}`, 20, 12, 'bold');
                addText(`Ação Recomendada: ${riskLevel.action}`);
            }
        }
        
        const fileName = `REBA_${data.funcao || 'Assessment'}_${data.data || new Date().toISOString().split('T')[0]}.pdf`;
        doc.save(fileName);
    }

    getRiskLevel(score) {
        for (const level of RISK_LEVELS) {
            if (level.score && level.score === score) {
                return level;
            } else if (level.score_range && score >= level.score_range[0] && score <= level.score_range[1]) {
                return level;
            }
        }
        return null;
    }
}

// Initialize the REBA Calculator when the page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing REBA Calculator');
    new REBACalculator();
});